package com.example.mydairyfarm

import android.content.Context
import android.view.View

fun storeScreen(a: Context, db: Db): Screen {
    val root = a.vbox(0, 16)

    // ----- add-purchase form (hidden until + is tapped) -----
    val form = a.vbox(C.LGREEN)
    val dateBtn = DateButton(a, today())
    val nameEt = a.et("பொருள் பெயர்: எ.கா. கடலை புண்ணாக்கு")
    val kgEt = a.et("கிலோ", true)
    val amtEt = a.et("தொகை ₹", true)
    val rateTv = a.tv("", 13f, false, C.MUTED)
    val listBox = a.vbox(0, 0)

    fun refresh() {
        listBox.removeAllViews()
        for (it0 in db.items()) {
            val c = a.vbox(C.LBLUE)
            val line = a.hbox()
            val left = a.vbox(0, 0)
            left.add(a.tv(it0.name, 18f, true))
            left.add(a.tv("சராசரி விலை: " + rateStr(it0.avgRate) + " / kg", 14f))
            line.add(left, 0, -2, 1f)
            val st = a.tv("இருப்பு\n" + f1(it0.stock) + " kg", 15f, true, if (it0.stock < 0) C.RED else C.GREEN)
            st.gravity = android.view.Gravity.END
            line.add(st, -2, -2)
            c.add(line)
            listBox.add(c, -1, -2, 0f, 0, 0, 0, 10)
        }
        listBox.add(a.tv("கொள்முதல் விவரம்", 18f, true), -1, -2, 0f, 0, 8, 0, 6)
        val buys = db.buys()
        if (buys.isEmpty()) listBox.add(a.tv("கொள்முதல் இல்லை", 14f, false, C.MUTED))
        for (b in buys) {
            val c = a.vbox(C.GRAY, 12)
            val line = a.hbox()
            val left = a.vbox(0, 0)
            left.add(a.tv(b.item, 16f, true))
            val rate = if (b.kg > 0) b.amount / b.kg else 0.0
            left.add(a.tv(disp(b.date) + " • " + f1(b.kg) + " kg × " + rateStr(rate), 12f, false, C.MUTED))
            line.add(left, 0, -2, 1f)
            line.add(a.tv(money(b.amount), 16f, true), -2, -2, 0f, 0, 0, 8, 0)
            val del = a.tv("🗑️", 20f)
            del.setOnClickListener {
                a.confirm("இந்த கொள்முதலை நீக்கவா?") {
                    db.deleteBuy(b.id)
                    refresh()
                }
            }
            line.add(del, -2, -2)
            c.add(line)
            listBox.add(c, -1, -2, 0f, 0, 0, 0, 8)
        }
    }

    fun updateRate() {
        val k = kgEt.text.toString().num()
        val amt = amtEt.text.toString().num()
        rateTv.text = if (k > 0) rateStr(amt / k) + " / kg" else ""
    }
    kgEt.onChange { updateRate() }
    amtEt.onChange { updateRate() }

    fun closeForm() {
        nameEt.setText("")
        kgEt.setText("")
        amtEt.setText("")
        form.visibility = View.GONE
    }

    form.add(dateBtn)
    form.add(nameEt, -1, -2, 0f, 0, 10, 0, 0)
    val l2 = a.hbox()
    l2.add(kgEt, 0, -2, 1f, 0, 0, 6, 0)
    l2.add(amtEt, 0, -2, 1f, 6, 0, 0, 0)
    form.add(l2, -1, -2, 0f, 0, 10, 0, 0)
    form.add(rateTv, -1, -2, 0f, 4, 4, 0, 0)
    val l3 = a.hbox()
    l3.gravity = android.view.Gravity.END or android.view.Gravity.CENTER_VERTICAL
    val cancel = a.tv("ரத்து", 16f, true, C.BLUE)
    cancel.setPadding(a.dp(16), a.dp(10), a.dp(16), a.dp(10))
    cancel.setOnClickListener { closeForm() }
    l3.add(cancel, -2, -2)
    l3.add(a.btn("சேமி") {
        val n = nameEt.text.toString().trim()
        val k = kgEt.text.toString().num()
        val amt = amtEt.text.toString().num()
        if (n.isEmpty() || k <= 0 || amt <= 0) {
            a.toast("பெயர், கிலோ, தொகை உள்ளிடவும்")
        } else {
            db.addBuy(dateBtn.value, n, k, amt)
            closeForm()
            refresh()
            a.toast("சேமிக்கப்பட்டது ✔")
        }
    }, -2, -2)
    form.add(l3, -1, -2, 0f, 0, 8, 0, 0)
    form.visibility = View.GONE

    root.add(form, -1, -2, 0f, 0, 0, 0, 12)
    root.add(listBox)
    refresh()

    return Screen("ஸ்டோர்", a.scroll(root)) {
        form.visibility = if (form.visibility == View.GONE) View.VISIBLE else View.GONE
    }
}
