package com.example.mydairyfarm

import android.content.Context
import android.view.Gravity
import android.view.View
import android.widget.CheckBox

fun expenseScreen(a: Context, db: Db): Screen {
    var date = today()
    var editId = 0L

    val root = a.vbox(0, 16)
    val form = a.vbox(C.LGREEN)
    val nameEt = a.et("செலவு பெயர்: கூலி")
    val amtEt = a.et("₹ தொகை", true)
    val daily = CheckBox(a)
    daily.text = "தினமும் (அடுத்த நாட்களுக்கும் தொடரும்)"
    val listBox = a.vbox(0, 0)

    fun refresh() {
        listBox.removeAllViews()
        val list = db.expensesFor(date)
        val card = a.vbox(C.LORANGE)
        card.add(a.tv("🧾 செலவுகள்", 18f, true), -1, -2, 0f, 0, 0, 0, 6)
        if (list.isEmpty()) card.add(a.tv("செலவு இல்லை", 14f, false, C.MUTED))
        var total = 0.0
        for (e in list) {
            total += e.amount
            val row = a.hbox()
            row.setPadding(0, a.dp(6), 0, a.dp(6))
            val left = a.vbox(0, 0)
            left.add(a.tv(e.name, 16f, true))
            left.add(a.tv(if (e.daily) "🔁 தினமும்" else "ஒருமுறை", 12f, false, C.MUTED))
            row.add(left, 0, -2, 1f)
            row.add(a.tv(money(e.amount), 16f, true), -2, -2, 0f, 0, 0, 8, 0)
            val ed = a.tv("✏️", 20f)
            ed.setOnClickListener {
                editId = e.id
                nameEt.setText(e.name)
                amtEt.setText(nz(e.amount))
                daily.isChecked = e.daily
                form.visibility = View.VISIBLE
            }
            row.add(ed, -2, -2, 0f, 0, 0, 8, 0)
            val del = a.tv("🗑️", 20f)
            del.setOnClickListener {
                a.confirm("இந்த செலவை நீக்கவா?") {
                    db.deleteExpense(e.id)
                    refresh()
                }
            }
            row.add(del, -2, -2)
            card.add(row)
        }
        listBox.add(card)
        val t = a.kv("🟠 இந்த நாள் மொத்த செலவு", money(total), true)
        listBox.add(t, -1, -2, 0f, 4, 14, 4, 0)
    }

    fun clearForm() {
        editId = 0L
        nameEt.setText("")
        amtEt.setText("")
        daily.isChecked = false
        form.visibility = View.GONE
    }

    form.add(nameEt)
    form.add(amtEt, -1, -2, 0f, 0, 8, 0, 0)
    form.add(daily, -1, -2, 0f, 0, 4, 0, 0)
    val btns = a.hbox()
    btns.gravity = Gravity.END or Gravity.CENTER_VERTICAL
    val cancel = a.tv("ரத்து", 16f, true, C.BLUE)
    cancel.setPadding(a.dp(16), a.dp(10), a.dp(16), a.dp(10))
    cancel.setOnClickListener { clearForm() }
    btns.add(cancel, -2, -2)
    btns.add(a.btn("சேமி") {
        val n = nameEt.text.toString().trim()
        val amt = amtEt.text.toString().num()
        if (n.isEmpty() || amt <= 0) {
            a.toast("பெயர், தொகை உள்ளிடவும்")
        } else {
            db.saveExpense(editId, date, n, amt, daily.isChecked)
            clearForm()
            refresh()
            a.toast("சேமிக்கப்பட்டது ✔")
        }
    }, -2, -2)
    form.add(btns, -1, -2, 0f, 0, 8, 0, 0)
    form.visibility = View.GONE

    root.add(DateButton(a, date) { d ->
        date = d
        refresh()
    })
    root.add(form, -1, -2, 0f, 0, 12, 0, 0)
    root.add(listBox, -1, -2, 0f, 0, 12, 0, 0)
    refresh()

    return Screen("செலவு", a.scroll(root)) {
        if (form.visibility == View.GONE) {
            form.visibility = View.VISIBLE
        } else {
            clearForm()
        }
    }
}
