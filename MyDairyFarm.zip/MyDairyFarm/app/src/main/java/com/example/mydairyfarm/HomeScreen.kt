package com.example.mydairyfarm

import android.content.Context
import android.view.Gravity

fun homeScreen(a: Context, db: Db): Screen {
    val root = a.vbox(0, 0)

    val hero = a.hbox()
    hero.gravity = Gravity.CENTER
    hero.setBackgroundColor(0xFF7FB241.toInt())
    hero.setPadding(0, a.dp(24), 0, a.dp(24))
    hero.addView(a.tv("🐄", 64f))
    root.add(hero)

    val body = a.vbox(0, 16)
    root.add(body)

    val td = today()
    val yd = addDays(td, -1)
    var any = false
    for ((label, d) in listOf("நேற்று" to yd, "இன்று" to td)) {
        val m = db.getMilk(d) ?: continue
        any = true
        val c = a.vbox(C.LBLUE)
        c.add(a.tv(label + " (" + disp(d) + ")", 18f, true))
        c.add(a.kv("☀️ காலை", f1(m.mq) + " லி × " + rateStr(m.mr)))
        c.add(a.kv("🌙 இரவு", f1(m.nq) + " லி × " + rateStr(m.nr)))
        c.add(a.kv("🟢 மொத்த பால்", f1(m.liters) + " லி"))
        c.add(a.kv("🔵 வரவு", money(m.income), true))
        body.add(c, b = 12)
    }
    if (!any) {
        body.add(a.tv("இன்னும் பால் பதிவு இல்லை. 'தினசரி பதிவு' மெனுவில் சேர்க்கவும்.", 15f, false, C.MUTED), b = 12)
    }

    val days = db.report(addDays(td, -9), td)
    val card = a.vbox(C.LORANGE)
    card.add(a.tv("📅 கடந்த 10 நாட்கள்", 18f, true))
    card.add(a.kv("🔵 மொத்த வரவு", money(days.sumOf { it.income })))
    card.add(a.kv("🟠 மொத்த செலவு", money(days.sumOf { it.cost })))
    body.add(card)

    return Screen("என் பால் பண்ணை", a.scroll(root))
}
