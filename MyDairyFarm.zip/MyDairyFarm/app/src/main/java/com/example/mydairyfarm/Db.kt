package com.example.mydairyfarm

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Milk(val mq: Double, val mr: Double, val nq: Double, val nr: Double) {
    val liters: Double get() = mq + nq
    val income: Double get() = mq * mr + nq * nr
}

data class Feed(val sess: String, val item: String, val kg: Double, val rate: Double)
data class ItemInfo(val name: String, val avgRate: Double, val stock: Double)
data class Buy(val id: Long, val date: String, val item: String, val kg: Double, val amount: Double)
data class Expense(val id: Long, val date: String, val name: String, val amount: Double, val daily: Boolean)
data class DayRow(val date: String, val liters: Double, val income: Double, val feed: Double, val misc: Double) {
    val cost: Double get() = feed + misc
    val profit: Double get() = income - cost
}

class Db(ctx: Context) : SQLiteOpenHelper(ctx, "dairy.db", null, 1) {

    override fun onCreate(d: SQLiteDatabase) {
        d.execSQL("CREATE TABLE milk(date TEXT PRIMARY KEY, m_q REAL, m_r REAL, n_q REAL, n_r REAL)")
        d.execSQL("CREATE TABLE feed(id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, sess TEXT, item TEXT, kg REAL, rate REAL)")
        d.execSQL("CREATE TABLE buy(id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, item TEXT, kg REAL, amount REAL)")
        d.execSQL("CREATE TABLE expense(id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, name TEXT, amount REAL, daily INTEGER)")
    }

    override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) {}

    private fun <T> query(sql: String, args: Array<String> = emptyArray(), f: (Cursor) -> T): List<T> {
        val out = ArrayList<T>()
        readableDatabase.rawQuery(sql, args).use { c ->
            while (c.moveToNext()) out.add(f(c))
        }
        return out
    }

    // ---------- milk ----------
    private fun milkOf(c: Cursor) = Milk(c.getDouble(0), c.getDouble(1), c.getDouble(2), c.getDouble(3))

    fun getMilk(date: String): Milk? =
        query("SELECT m_q,m_r,n_q,n_r FROM milk WHERE date=?", arrayOf(date)) { milkOf(it) }.firstOrNull()

    fun lastMilk(): Milk? =
        query("SELECT m_q,m_r,n_q,n_r FROM milk ORDER BY date DESC LIMIT 1") { milkOf(it) }.firstOrNull()

    fun saveMilk(date: String, m: Milk) {
        val v = ContentValues()
        v.put("date", date)
        v.put("m_q", m.mq)
        v.put("m_r", m.mr)
        v.put("n_q", m.nq)
        v.put("n_r", m.nr)
        writableDatabase.insertWithOnConflict("milk", null, v, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun deleteMilk(date: String) {
        writableDatabase.delete("milk", "date=?", arrayOf(date))
    }

    // ---------- feed usage ----------
    fun feedFor(date: String): List<Feed> =
        query("SELECT sess,item,kg,rate FROM feed WHERE date=? ORDER BY id", arrayOf(date)) {
            Feed(it.getString(0), it.getString(1), it.getDouble(2), it.getDouble(3))
        }

    fun saveFeed(date: String, list: List<Feed>) {
        val d = writableDatabase
        d.beginTransaction()
        try {
            d.delete("feed", "date=?", arrayOf(date))
            for (f in list) {
                val v = ContentValues()
                v.put("date", date)
                v.put("sess", f.sess)
                v.put("item", f.item)
                v.put("kg", f.kg)
                v.put("rate", f.rate)
                d.insert("feed", null, v)
            }
            d.setTransactionSuccessful()
        } finally {
            d.endTransaction()
        }
    }

    fun feedCost(date: String): Double =
        query("SELECT COALESCE(SUM(kg*rate),0) FROM feed WHERE date=?", arrayOf(date)) { it.getDouble(0) }.first()

    // ---------- store ----------
    fun items(): List<ItemInfo> {
        val bought = query("SELECT item, SUM(kg), SUM(amount) FROM buy GROUP BY item ORDER BY item") {
            Triple(it.getString(0), it.getDouble(1), it.getDouble(2))
        }
        val used = query("SELECT item, SUM(kg) FROM feed GROUP BY item") {
            Pair(it.getString(0), it.getDouble(1))
        }.toMap()
        return bought.map { b ->
            ItemInfo(b.first, if (b.second > 0) b.third / b.second else 0.0, b.second - (used[b.first] ?: 0.0))
        }
    }

    fun stockExcluding(item: String, date: String): Double {
        val b = query("SELECT COALESCE(SUM(kg),0) FROM buy WHERE item=?", arrayOf(item)) { it.getDouble(0) }.first()
        val u = query("SELECT COALESCE(SUM(kg),0) FROM feed WHERE item=? AND date<>?", arrayOf(item, date)) { it.getDouble(0) }.first()
        return b - u
    }

    fun addBuy(date: String, item: String, kg: Double, amount: Double) {
        val v = ContentValues()
        v.put("date", date)
        v.put("item", item)
        v.put("kg", kg)
        v.put("amount", amount)
        writableDatabase.insert("buy", null, v)
    }

    fun deleteBuy(id: Long) {
        writableDatabase.delete("buy", "id=?", arrayOf(id.toString()))
    }

    fun buys(): List<Buy> =
        query("SELECT id,date,item,kg,amount FROM buy ORDER BY date DESC, id DESC") {
            Buy(it.getLong(0), it.getString(1), it.getString(2), it.getDouble(3), it.getDouble(4))
        }

    // ---------- expenses ----------
    fun expensesFor(date: String): List<Expense> =
        query(
            "SELECT id,date,name,amount,daily FROM expense WHERE (daily=0 AND date=?) OR (daily=1 AND date<=?) ORDER BY id",
            arrayOf(date, date)
        ) {
            Expense(it.getLong(0), it.getString(1), it.getString(2), it.getDouble(3), it.getInt(4) == 1)
        }

    fun saveExpense(id: Long, date: String, name: String, amount: Double, daily: Boolean) {
        val v = ContentValues()
        v.put("name", name)
        v.put("amount", amount)
        v.put("daily", if (daily) 1 else 0)
        if (id == 0L) {
            v.put("date", date)
            writableDatabase.insert("expense", null, v)
        } else {
            writableDatabase.update("expense", v, "id=?", arrayOf(id.toString()))
        }
    }

    fun deleteExpense(id: Long) {
        writableDatabase.delete("expense", "id=?", arrayOf(id.toString()))
    }

    fun miscTotal(date: String): Double =
        query(
            "SELECT COALESCE(SUM(amount),0) FROM expense WHERE (daily=0 AND date=?) OR (daily=1 AND date<=?)",
            arrayOf(date, date)
        ) { it.getDouble(0) }.first()

    // ---------- report ----------
    fun report(from: String, to: String): List<DayRow> {
        val out = ArrayList<DayRow>()
        var d = from
        var guard = 0
        while (d <= to && guard < 400) {
            val m = getMilk(d)
            out.add(DayRow(d, m?.liters ?: 0.0, m?.income ?: 0.0, feedCost(d), miscTotal(d)))
            d = addDays(d, 1)
            guard++
        }
        return out
    }
}
