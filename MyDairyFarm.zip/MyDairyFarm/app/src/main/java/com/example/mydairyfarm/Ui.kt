package com.example.mydairyfarm

import android.app.DatePickerDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object C {
    val BLUE = 0xFF0D4EA6.toInt()
    val LBLUE = 0xFFE3ECFA.toInt()
    val LGREEN = 0xFFE3F3E6.toInt()
    val LORANGE = 0xFFFDEBD7.toInt()
    val GRAY = 0xFFF3F4F8.toInt()
    val TEXT = 0xFF222222.toInt()
    val MUTED = 0xFF777777.toInt()
    val GREEN = 0xFF2E7D32.toInt()
    val RED = 0xFFC62828.toInt()
}

class Screen(val title: String, val view: View, val onPlus: (() -> Unit)? = null)

// ---------- formatting ----------
fun f1(d: Double): String = String.format(Locale.US, "%.1f", d)
fun money(d: Double): String = "₹" + String.format(Locale.US, "%,.0f", d)
fun rateStr(d: Double): String = "₹" + f1(d)
fun nz(d: Double): String = if (d == 0.0) "" else if (d % 1.0 == 0.0) d.toLong().toString() else d.toString()
fun String.num(): Double = this.trim().toDoubleOrNull() ?: 0.0

// ---------- dates (stored as yyyy-MM-dd) ----------
val ISO = SimpleDateFormat("yyyy-MM-dd", Locale.US)
fun today(): String = ISO.format(Date())
fun disp(iso: String): String {
    val p = iso.split("-")
    return p[2] + "-" + p[1] + "-" + p[0]
}
fun dispShort(iso: String): String {
    val p = iso.split("-")
    return p[2] + "-" + p[1] + "-" + p[0].substring(2)
}
fun addDays(iso: String, n: Int): String {
    val c = Calendar.getInstance()
    c.time = ISO.parse(iso)!!
    c.add(Calendar.DAY_OF_MONTH, n)
    return ISO.format(c.time)
}

// ---------- view helpers ----------
fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.bg(color: Int, radius: Int = 12, stroke: Int = 0, strokeColor: Int = 0): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color)
    g.cornerRadius = dp(radius).toFloat()
    if (stroke > 0) g.setStroke(dp(stroke), strokeColor)
    return g
}

fun Context.tv(text: String, size: Float = 15f, bold: Boolean = false, color: Int = C.TEXT): TextView {
    val t = TextView(this)
    t.text = text
    t.textSize = size
    t.setTextColor(color)
    if (bold) t.setTypeface(null, Typeface.BOLD)
    return t
}

fun Context.et(hint: String, number: Boolean = false): EditText {
    val e = EditText(this)
    e.hint = hint
    e.textSize = 15f
    e.setSingleLine(true)
    if (number) e.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
    e.background = bg(Color.WHITE, 8, 1, 0xFF888888.toInt())
    e.setPadding(dp(12), dp(10), dp(12), dp(10))
    return e
}

fun Context.btn(text: String, filled: Boolean = true, onClick: () -> Unit): TextView {
    val b = tv(text, 15f, true, if (filled) Color.WHITE else C.BLUE)
    b.gravity = Gravity.CENTER
    b.setPadding(dp(18), dp(12), dp(18), dp(12))
    b.background = if (filled) bg(C.BLUE, 24) else bg(Color.WHITE, 24, 2, C.BLUE)
    b.setOnClickListener { onClick() }
    return b
}

fun Context.vbox(color: Int = 0, pad: Int = 14): LinearLayout {
    val l = LinearLayout(this)
    l.orientation = LinearLayout.VERTICAL
    if (color != 0) l.background = bg(color, 14)
    l.setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
    return l
}

fun Context.hbox(): LinearLayout {
    val l = LinearLayout(this)
    l.orientation = LinearLayout.HORIZONTAL
    l.gravity = Gravity.CENTER_VERTICAL
    return l
}

fun Context.kv(left: String, right: String, bold: Boolean = false, rightColor: Int = C.TEXT): LinearLayout {
    val row = hbox()
    row.add(tv(left, 15f, bold), 0, -2, 1f)
    row.add(tv(right, 15f, bold, rightColor), -2, -2)
    row.setPadding(0, dp(4), 0, dp(4))
    return row
}

fun Context.scroll(v: View): ScrollView {
    val s = ScrollView(this)
    s.addView(v)
    return s
}

fun Context.toast(s: String) {
    Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}

fun Context.confirm(msg: String, onYes: () -> Unit) {
    android.app.AlertDialog.Builder(this)
        .setMessage(msg)
        .setPositiveButton("ஆம்") { _, _ -> onYes() }
        .setNegativeButton("இல்லை", null)
        .show()
}

fun Context.pickDate(iso: String, onPick: (String) -> Unit) {
    val p = iso.split("-")
    DatePickerDialog(
        this,
        { _, y, m, d -> onPick(String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d)) },
        p[0].toInt(), p[1].toInt() - 1, p[2].toInt()
    ).show()
}

fun LinearLayout.add(
    v: View, w: Int = -1, h: Int = -2, weight: Float = 0f,
    l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0
): View {
    val p = LinearLayout.LayoutParams(w, h, weight)
    p.setMargins(context.dp(l), context.dp(t), context.dp(r), context.dp(b))
    addView(v, p)
    return v
}

fun EditText.onChange(f: () -> Unit) {
    addTextChangedListener(object : TextWatcher {
        override fun afterTextChanged(s: Editable?) { f() }
        override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
        override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
    })
}

class DateButton(ctx: Context, var value: String, private val label: String = "தேதி", private val onChange: (String) -> Unit) : TextView(ctx) {
    init {
        textSize = 16f
        setTextColor(C.BLUE)
        gravity = Gravity.CENTER
        setPadding(ctx.dp(12), ctx.dp(12), ctx.dp(12), ctx.dp(12))
        background = ctx.bg(Color.WHITE, 28, 2, C.BLUE)
        refreshText()
        setOnClickListener {
            ctx.pickDate(value) { v ->
                value = v
                refreshText()
                onChange(v)
            }
        }
    }

    private fun refreshText() {
        text = "📅 " + label + ": " + disp(value)
    }
}
