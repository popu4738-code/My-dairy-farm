package com.example.mydairyfarm

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout

class MainActivity : AppCompatActivity() {
    private lateinit var db: Db
    private lateinit var title: TextView
    private lateinit var plus: TextView
    private lateinit var content: FrameLayout
    private lateinit var drawer: DrawerLayout
    private var current = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = Db(this)
        window.statusBarColor = C.BLUE

        drawer = DrawerLayout(this)

        val main = LinearLayout(this)
        main.orientation = LinearLayout.VERTICAL
        val bar = hbox()
        bar.setBackgroundColor(C.BLUE)
        bar.setPadding(dp(16), dp(14), dp(16), dp(14))
        val menu = tv("☰", 24f, true, Color.WHITE)
        menu.setOnClickListener { drawer.openDrawer(GravityCompat.START) }
        title = tv("", 20f, true, Color.WHITE)
        plus = tv("＋", 28f, true, Color.WHITE)
        bar.add(menu, -2, -2, 0f, 0, 0, 16, 0)
        bar.add(title, 0, -2, 1f)
        bar.add(plus, -2, -2)
        content = FrameLayout(this)
        main.add(bar)
        main.add(content, -1, 0, 1f)
        drawer.addView(main, DrawerLayout.LayoutParams(-1, -1))

        val side = vbox(Color.WHITE, 0)
        val head = hbox()
        head.setBackgroundColor(0xFF7FB241.toInt())
        head.setPadding(dp(20), dp(40), dp(20), dp(24))
        head.add(tv("🐄 என் பால் பண்ணை", 20f, true, Color.WHITE))
        side.add(head)
        val names = listOf("🏠  முகப்பு", "📝  தினசரி பதிவு", "📦  ஸ்டோர்", "🧾  செலவு", "📊  அறிக்கைகள்")
        names.forEachIndexed { i, n ->
            val item = tv(n, 17f)
            item.setPadding(dp(20), dp(16), dp(20), dp(16))
            item.setOnClickListener { show(i) }
            side.add(item)
        }
        val dlp = DrawerLayout.LayoutParams(dp(280), -1)
        dlp.gravity = Gravity.START
        drawer.addView(side, dlp)

        setContentView(drawer)
        show(0)
    }

    private fun show(i: Int) {
        current = i
        val s = when (i) {
            0 -> homeScreen(this, db)
            1 -> entryScreen(this, db)
            2 -> storeScreen(this, db)
            3 -> expenseScreen(this, db)
            else -> reportScreen(this, db)
        }
        title.text = s.title
        val action = s.onPlus
        plus.visibility = if (action != null) View.VISIBLE else View.GONE
        plus.setOnClickListener { action?.invoke() }
        content.removeAllViews()
        content.addView(s.view)
        drawer.closeDrawers()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawers()
        } else if (current != 0) {
            show(0)
        } else {
            super.onBackPressed()
        }
    }
}
