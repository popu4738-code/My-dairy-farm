package com.example.mydairyfarm

import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView

class FeedRow(
    a: Context,
    val sess: String,
    names: List<String>,
    onChange: () -> Unit,
    onDelete: (FeedRow) -> Unit
) {
    val view: LinearLayout = a.vbox(0, 0)
    val spinner = Spinner(a)
    val kg: EditText = a.et("கிலோ", true)
    val cost: TextView = a.tv("", 13f, true)
    val bal: TextView = a.tv("", 12f, false, C.MUTED)

    init {
        spinner.adapter = ArrayAdapter(a, android.R.layout.simple_spinner_dropdown_item, names)
        cost.gravity = Gravity.END
        val line = a.hbox()
        line.add(spinner, 0, -2, 1.3f)
        line.add(kg, 0, -2, 1f, 6, 0, 6, 0)
        line.add(cost, 0, -2, 1.1f)
        val del = a.tv("🗑️", 20f)
        del.setOnClickListener { onDelete(this) }
        line.add(del, -2, -2, 0f, 6, 0, 0, 0)
        view.add(line)
        view.add(bal, -1, -2, 0f, 4, 0, 0, 0)
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { onChange() }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        kg.onChange { onChange() }
    }

    fun item(): String = (spinner.selectedItem as? String) ?: ""
}

fun entryScreen(a: Context, db: Db): Screen {
    var date = today()
    val items = db.items()
    val names = items.map { it.name }
    val rows = ArrayList<FeedRow>()
    val containers = mapOf("M" to a.vbox(0, 0), "N" to a.vbox(0, 0))

    val mq = a.et("பால் (லி)", true)
    val mr = a.et("விலை ₹", true)
    val nq = a.et("பால் (லி)", true)
    val nr = a.et("விலை ₹", true)

    fun updateAll() {
        val used = HashMap<String, Double>()
        for (r in rows) {
            used[r.item()] = (used[r.item()] ?: 0.0) + r.kg.text.toString().num()
        }
        for (r in rows) {
            val info = items.firstOrNull { x -> x.name == r.item() }
            val rate = info?.avgRate ?: 0.0
            val kgv = r.kg.text.toString().num()
            r.cost.text = rateStr(rate) + "/kg\n" + money(kgv * rate)
            val base = if (info != null) db.stockExcluding(r.item(), date) else 0.0
            val balance = base - (used[r.item()] ?: 0.0)
            r.bal.text = "இருப்பு: " + f1(balance) + " kg"
            r.bal.setTextColor(if (balance < 0) C.RED else C.MUTED)
        }
    }

    fun addRow(sess: String, item: String? = null, kgv: Double = 0.0) {
        if (names.isEmpty()) {
            a.toast("முதலில் ஸ்டோரில் தீவனம் சேர்க்கவும்")
            return
        }
        val row = FeedRow(a, sess, names, { updateAll() }) { r ->
            rows.remove(r)
            containers[sess]!!.removeView(r.view)
            updateAll()
        }
        if (item != null) {
            val i = names.indexOf(item)
            if (i >= 0) row.spinner.setSelection(i)
        }
        if (kgv > 0) row.kg.setText(f1(kgv))
        rows.add(row)
        containers[sess]!!.add(row.view, -1, -2, 0f, 0, 8, 0, 0)
        updateAll()
    }

    fun load() {
        rows.clear()
        containers.values.forEach { it.removeAllViews() }
        val m = db.getMilk(date)
        if (m != null) {
            mq.setText(nz(m.mq)); mr.setText(nz(m.mr))
            nq.setText(nz(m.nq)); nr.setText(nz(m.nr))
        } else {
            val last = db.lastMilk()
            mq.setText(""); nq.setText("")
            mr.setText(if (last != null) nz(last.mr) else "")
            nr.setText(if (last != null) nz(last.nr) else "")
        }
        for (f in db.feedFor(date)) addRow(f.sess, f.item, f.kg)
        updateAll()
    }

    fun save() {
        val used = HashMap<String, Double>()
        for (r in rows) {
            used[r.item()] = (used[r.item()] ?: 0.0) + r.kg.text.toString().num()
        }
        for ((name, u) in used) {
            if (name.isNotEmpty() && db.stockExcluding(name, date) - u < -0.0001) {
                a.toast("இருப்பு போதவில்லை: " + name)
                return
            }
        }
        val m = Milk(mq.text.toString().num(), mr.text.toString().num(), nq.text.toString().num(), nr.text.toString().num())
        if (m.mq + m.nq > 0) db.saveMilk(date, m) else db.deleteMilk(date)
        val list = ArrayList<Feed>()
        for (r in rows) {
            val k = r.kg.text.toString().num()
            if (k > 0 && r.item().isNotEmpty()) {
                val rate = items.firstOrNull { x -> x.name == r.item() }?.avgRate ?: 0.0
                list.add(Feed(r.sess, r.item(), k, rate))
            }
        }
        db.saveFeed(date, list)
        a.toast("சேமிக்கப்பட்டது ✔")
    }

    val root = a.vbox(0, 16)
    val top = a.vbox(0, 0)
    root.add(top)

    fun section(title: String, sess: String, q: EditText, rt: EditText) {
        val h = a.tv(title, 18f, true)
        h.setBackgroundColor(C.LBLUE)
        h.setPadding(a.dp(12), a.dp(10), a.dp(12), a.dp(10))
        root.add(h, -1, -2, 0f, 0, 12, 0, 0)
        val line = a.hbox()
        line.add(q, 0, -2, 1f, 0, 0, 8, 0)
        line.add(rt, 0, -2, 1f)
        root.add(line, -1, -2, 0f, 0, 8, 0, 0)
        root.add(a.tv("🌾 தீவனம்", 15f, true), -1, -2, 0f, 0, 10, 0, 0)
        root.add(containers[sess]!!)
        root.add(a.btn("＋ தீவனம் சேர்", false) { addRow(sess) }, -1, -2, 0f, 0, 8, 0, 0)
    }

    section("☀️ காலை", "M", mq, mr)
    section("🌙 இரவு", "N", nq, nr)
    root.add(a.btn("✔ சேமி") { save() }, -1, -2, 0f, 0, 16, 0, 24)

    top.add(DateButton(a, date) { d ->
        date = d
        load()
    })
    load()

    return Screen("தினசரி பதிவு", a.scroll(root))
}
