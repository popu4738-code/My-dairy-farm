package com.example.mydairyfarm

import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.widget.LinearLayout

private fun tableRow(a: Context, cells: List<String>, bold: Boolean): LinearLayout {
    val row = a.hbox()
    row.setPadding(0, a.dp(3), 0, a.dp(3))
    cells.forEachIndexed { i, s ->
        val t = a.tv(s, 12f, bold)
        if (i > 0) t.gravity = Gravity.END
        row.add(t, 0, -2, if (i == 0) 1.3f else 1f)
    }
    return row
}

fun reportScreen(a: Context, db: Db): Screen {
    var tab = 0
    var day = today()
    var fromD = addDays(today(), -9)
    var toD = today()

    val root = a.vbox(0, 0)
    val tabs = a.hbox()
    val body = a.vbox(0, 16)
    val tabNames = listOf("தினசரி", "காலம்")
    val tabViews = tabNames.map { n ->
        val t = a.tv(n, 16f, true)
        t.gravity = Gravity.CENTER
        t.setPadding(0, a.dp(14), 0, a.dp(14))
        t
    }
    tabViews.forEach { tabs.add(it, 0, -2, 1f) }
    root.add(tabs)
    root.add(body)

    fun render() {
        tabViews.forEachIndexed { i, v ->
            v.setTextColor(if (i == tab) C.BLUE else C.MUTED)
            v.setBackgroundColor(if (i == tab) C.LBLUE else Color.WHITE)
        }
        body.removeAllViews()
        val f: String
        val t: String
        if (tab == 0) {
            body.add(DateButton(a, day, "தேதி") { d ->
                day = d
                render()
            })
            f = day
            t = day
        } else {
            val line = a.hbox()
            line.add(DateButton(a, fromD, "இருந்து") { d ->
                fromD = d
                render()
            }, 0, -2, 1f, 0, 0, 6, 0)
            line.add(DateButton(a, toD, "வரை") { d ->
                toD = d
                render()
            }, 0, -2, 1f, 6, 0, 0, 0)
            body.add(line)
            f = fromD
            t = toD
        }

        val days = db.report(f, t)
        val liters = days.sumOf { it.liters }
        val income = days.sumOf { it.income }
        val feed = days.sumOf { it.feed }
        val misc = days.sumOf { it.misc }
        val profit = income - feed - misc

        val sum = a.vbox(0, 0)
        sum.add(a.kv("🟢 மொத்த பால்", f1(liters) + " லி"))
        sum.add(a.kv("🔵 மொத்த வரவு", money(income)))
        sum.add(a.kv("🌾 தீவன செலவு", money(feed)))
        sum.add(a.kv("🧾 இதர செலவு", money(misc)))
        sum.add(a.kv("🟠 மொத்த செலவு", money(feed + misc)))
        sum.add(a.kv("💰 லாபம்", money(profit), true, if (profit >= 0) C.GREEN else C.RED))
        body.add(sum, -1, -2, 0f, 0, 14, 0, 0)

        if (tab == 1) {
            val h = a.tv("தேதி வாரியாக", 17f, true)
            h.setBackgroundColor(C.LBLUE)
            h.setPadding(a.dp(12), a.dp(10), a.dp(12), a.dp(10))
            body.add(h, -1, -2, 0f, 0, 16, 0, 8)
            body.add(tableRow(a, listOf("தேதி", "பால்", "வரவு", "செலவு", "லாபம்"), true))
            for (d in days.reversed()) {
                if (d.liters == 0.0 && d.cost == 0.0) continue
                body.add(
                    tableRow(
                        a,
                        listOf(dispShort(d.date), f1(d.liters), money(d.income), money(d.cost), money(d.profit)),
                        false
                    )
                )
            }
            body.add(
                tableRow(
                    a,
                    listOf("மொத்தம்", f1(liters), money(income), money(feed + misc), money(profit)),
                    true
                )
            )
        }
    }

    tabViews.forEachIndexed { i, v ->
        v.setOnClickListener {
            tab = i
            render()
        }
    }
    render()

    return Screen("அறிக்கைகள்", a.scroll(root))
}
