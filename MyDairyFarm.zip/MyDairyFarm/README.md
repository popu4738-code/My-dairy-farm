# என் பால் பண்ணை (My Dairy Farm)

Kotlin Android app (no extra libraries). Offline - data stays in phone (SQLite).

## APK build (GitHub)
1. Create a new GitHub repo, upload ALL files of this folder (keep `.github/workflows/build.yml`).
2. Repo -> Actions -> "Build APK" -> run (or just push to main).
3. When finished, open the run -> Artifacts -> `MyDairyFarm-apk` -> download -> install `app-debug.apk`.
